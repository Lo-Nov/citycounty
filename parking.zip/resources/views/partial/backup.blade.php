
<div class="col-md-4">
    <h2 class="heading-border">Referrals</h2>
    <ul class="list-unstyled list-referrals">
        <li>
            <p>
                <span class="value">3,454</span>
                <span class="text-muted">visits from Facebook</span>
            </p>
            <div class="progress progress-xs progress-transparent custom-color-blue">
                <div class="progress-bar" role="progressbar" aria-valuenow="87" aria-valuemin="0" aria-valuemax="100" style="width:87%"></div>
            </div>
        </li>
        <li>
            <p>
                <span class="value">2,102</span>
                <span class="text-muted">visits from Twitter</span>
            </p>
            <div class="progress progress-xs progress-transparent custom-color-purple">
                <div class="progress-bar" role="progressbar" aria-valuenow="34" aria-valuemin="0" aria-valuemax="100" style="width:34%"></div>
            </div>
        </li>
        <li>
            <p>
                <span class="value">2,874</span>
                <span class="text-muted">visits from Affiliates</span>
            </p>
            <div class="progress progress-xs progress-transparent custom-color-green">
                <div class="progress-bar" role="progressbar" aria-valuenow="67" aria-valuemin="0" aria-valuemax="100" style="width:67%"></div>
            </div>
        </li>
        <li>
            <p>
                <span class="value">2,874</span>
                <span class="text-muted">visits from Search</span>
            </p>
            <div class="progress progress-xs progress-transparent custom-color-yellow">
                <div class="progress-bar" role="progressbar" aria-valuenow="54" aria-valuemin="0" aria-valuemax="100" style="width:54%"></div>
            </div>
        </li>
    </ul>
</div>



<td>
    <a href="{{route('test',$inspect->business_id)}}" class="btn btn-info btn-xs" role="button">Approve</a>
</td>