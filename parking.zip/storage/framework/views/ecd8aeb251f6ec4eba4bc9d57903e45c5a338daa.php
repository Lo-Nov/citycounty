<!doctype html>
<html lang="en">
<title>Collections</title>
<?php echo $__env->make('partial.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<body>
<!-- WRAPPER -->
<div id="wrapper">
    <!-- NAVBAR -->
    <?php echo $__env->make('partial.topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <!-- END NAVBAR -->
    <!-- LEFT SIDEBAR -->
    <?php echo $__env->make('partial.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <!-- END LEFT SIDEBAR -->
    <!-- MAIN -->
    <div class="main">
        <!-- MAIN CONTENT -->
        <!-- MAIN CONTENT -->
        <div class="main-content">
            <div class="content-heading clearfix">
                <div class="heading-left">
                    <h1 class="page-title">Parking Queries - Detailed Report</h1>
                </div>
                <ul class="breadcrumb">
                    <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
                    <li><a href="#">attendants</a></li>
                    <li class="active">report</li>
                </ul>
            </div>
            <!-- FEATURED DATATABLE -->
            <div class="panel">
                <div class="panel-body">
                    <div class="tab-content">
                        <div class="tab-pane fade in active" id="tabitem1">

                            <!-- FEATURED DATATABLE -->
                            <div class="panel">
                                <div class="panel-body">
                                    <form action="<?php echo e(route('detailed')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="row">

                                            <div class="col-md-2">
                                                <div class="dropdown"><span>Sub County</span>
                                                    <select class="form-control" name="subcounties" id="countries">
                                                        <option value="ALL">Select Sub County</option>
                                                        <?php $__currentLoopData = $detailsCollections->subcounties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option ><?php echo e($value); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>

                                                </div>

                                            </div>
                                            <div class="col-md-2">
                                                <div class="dropdown">
                                                    <span>Zones</span>
                                                    <select class="form-control" name="zones" id="countries">
                                                        <option value="ALL">Select Zone</option>
                                                        <?php $__currentLoopData = $detailsCollections->zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option><?php echo e($value); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>

                                                </div>
                                            </div>
                                            <div class="col-md-2">
                                                <div class="dropdown">
                                                    <span>Attendant</span>
                                                    <select class="form-control" name="agents" id="countries">
                                                        <option value= 0 >Select Attendant</option>
                                                        <?php $__currentLoopData = $detailsCollections->agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                            <option value="<?php echo e($value->user_id); ?>"><?php echo e($value->username); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>

                                                </div>

                                            </div>
                                            <div class="col-md-2">
                                                <div class="dropdown">
                                                    <span>Streets</span>
                                                    <select class="form-control" name="streets" id="countries">
                                                        <option value="ALL">Select Street</option>
                                                        <?php $__currentLoopData = $detailsCollections->streets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option><?php echo e($value); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>

                                                </div>

                                            </div>

                                        <div class="col-md-3">
                                            <ul class="bread">
                                                <span> Select Date</span>
                                                    <div class="input-daterange input-group" data-provide="datepicker">
                                                        <input type="text" class="input-sm form-control" name="fromDate" placeholder="Search From">
                                                        <span class="input-group-addon"><i class="i ti-calendar"></i></span>
                                                        <input type="text" class="input-sm form-control" name="toDate" placeholder="Search To">
                                                    </div>

                                            </ul>

                                        </div>
                                            <div class="col-md-1">
                                                <span style="color: transparent"> Date</span>
                                                <button type="submit" class="btn btn-sm btn-success pull-right">
                                                    <i class="fa fa-filter"></i>Search
                                                </button>
                                            </div>
                                        </div>
                                        <span>

                                        </span>
                                    </form>
                                            </ul>
                                        </div>
                                    </div>




                                    <table id="example" class="table table-striped table-hover">
                                        <thead>
                                        <tr>
                                            <th>Number</th>
                                            <th>Registration Number</th>
                                            <th>Sub County</th>
                                            <th>Zone</th>
                                            <!-- <th>Vehicle Street</th> -->
                                            <th>Agent Name</th>
                                            <th>Status</th>
                                            <th>Date Queried</th>
                                        </tr>
                                        </thead>

                                        <tbody>
                                        <?php $__currentLoopData = $detailsCollections->total_queries_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($key+1); ?></td>
                                                <td> <a href="#"><?php echo e($item->vehicle_registration_no); ?></a></td>
                                                <td>
                                                    <?php echo e($item->constituency); ?>

                                                </td>
                                                <td><?php echo e($item->zone_code); ?></td>
                                                <!-- <td>
                                                    <?php echo e($item->street); ?>

                                                </td> -->
                                                <td><?php echo e($item->agent_name); ?></td>


                                                <td>
                                                    <?php if($item->status_code=="UNPAID"): ?>
                                                        <span class="btn btn-xs btn-danger">
                                             <?php echo e($item->status_code); ?>

                                        </span>
                                                    <?php elseif($item->status_code=="PAID"): ?>
                                                        <span class="btn btn-xs btn-success">
                                            <?php echo e($item->status_code); ?>

                                        </span>
                                                    <?php else: ?>
                                                        <span class="btn btn-xs btn-primary">
                                            <?php echo e($item->status_code); ?>

                                        </span>
                                                    <?php endif; ?>

                                                </td>
                                                <td><?php echo e(date('d-m-Y g:i a', strtotime($item->last_modified))); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                            <br>

                            <?php
                            $pay =  $detailsCollections->pages;
                            for ($x = 1; $x <= $pay; $x++) {?>
                            <a href="<?php echo e(route('dpages',$x)); ?>" class="btn btn-default btn-xs" role="button"><?php echo e($x); ?> &raquo;</a>
                            <?php
                            }
                            ?>
                                </div>


                            </div>
                            <!-- END FEATURED DATATABLE -->

                        </div>

                    </div>
                    <!-- END TABS WITH LABEL AND BADGE -->
                </div>
            </div>
            <!-- END FEATURED DATATABLE -->
        </div>

        <!-- END MAIN CONTENT -->
        <!-- RIGHT SIDEBAR -->
    <?php echo $__env->make('partial.rightsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- END RIGHT SIDEBAR -->
    </div>
    <!-- END MAIN -->
    <div class="clearfix"></div>
    <!-- FOOTER -->
<?php echo $__env->make('partial.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- END FOOTER -->
</div>
<?php echo $__env->make('partial.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php /**PATH C:\xampp\htdocs\finance\resources\views/collection/detailedcollections.blade.php ENDPATH**/ ?>