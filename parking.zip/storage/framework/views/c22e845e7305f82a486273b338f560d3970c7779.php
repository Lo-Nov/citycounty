<footer>
    <div class="container-fluid">
        <p class="copyright">&copy; <?php echo date("Y"); ?> <strong>Powered by National Bank of Kenya</strong>. All Rights Reserved.</p>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\finance\resources\views/partial/footer.blade.php ENDPATH**/ ?>