<?php
/**
 * Created by PhpStorm.
 * User: hp
 * Date: 4/18/2019
 * Time: 7:55 AM
 */

namespace App\Http\Controllers;


class Toastr
{

}